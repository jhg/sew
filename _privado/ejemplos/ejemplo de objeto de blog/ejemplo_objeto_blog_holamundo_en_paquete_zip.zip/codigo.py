contexto_actual = {
    "nombre_objeto": self.nombre,
    "ip": socket.gethostbyname(socket.gethostname()),
}
